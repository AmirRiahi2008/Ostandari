<?php

return ['default' => 'local', 'disks' => [
    'local' => ['driver' => 'local', 'root' => storage_path('app/private'), 'throw' => true],
    'public' => ['driver' => 'local', 'root' => storage_path('app/public'), 'url' => env('APP_URL').'/storage', 'visibility' => 'public', 'throw' => true],
], 'links' => [public_path('storage') => storage_path('app/public')]];
